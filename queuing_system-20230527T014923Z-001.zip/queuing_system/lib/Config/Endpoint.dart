class AppEndpoint {
  static String endPointDomain = "http://192.168.185.105/queuing/mobileapi/";
  static String imageEndPoint = "http://192.168.185.105/queuing/images/";
}
