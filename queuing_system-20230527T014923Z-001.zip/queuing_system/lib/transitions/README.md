# kezarfeatures

# Page Transitions

- [Source from Divyanshu Bhargava](https://github.com/divyanshub024)

1. Enter Exit
2. Fade
3. Rotation
4. Scale Rotate
5. Size
6. Slide