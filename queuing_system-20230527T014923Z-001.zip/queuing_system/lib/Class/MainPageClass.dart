import 'package:flutter/material.dart';

class MainPageClass {
  TabController tabController;
  GlobalKey scaffoldKey = GlobalKey<ScaffoldState>();
  bool isDispose = false;
  
}