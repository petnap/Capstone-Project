package com.example.queuing_system

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
