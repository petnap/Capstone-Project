package com.example.mobile_queuing_system_and_tracker_with_qr_code_main

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
