class MonthsModel {
  MonthsModel(this.monthname, this.number);

  final String monthname;
  final int number;
}
