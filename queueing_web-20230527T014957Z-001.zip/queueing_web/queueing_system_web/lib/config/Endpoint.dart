class AppEndpoint {
  static String endPointDomain = "http://190.160.15.118/queuing/webapi/";
}
