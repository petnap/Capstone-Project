package com.example.queueing_system_web

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
